================================================================================
AppShots Screenshot Studio — Store Asset Export
================================================================================

Project Name:    iPad MCP Store Package
Generated At:    2026-10-20T13:55:25.945Z
Target Store:    apple-app-store
Dimensions:      2048 x 2732 px (12.9 inch (iPad Pro))
Screenshots:     1

--------------------------------------------------------------------------------
Archive Structure:
--------------------------------------------------------------------------------
  appshots-export/
    ├── screenshots/        Store-ready PNG files for App Store Connect submission
    ├── project/
    │   ├── project.json    Native AppShots project file for continued editing
    │   └── assets/         Extracted source screenshot assets
    ├── manifest.json       Complete technical manifest with dimensions & copy
    └── README.txt          This guide

--------------------------------------------------------------------------------
How to Reopen and Edit in AppShots:
--------------------------------------------------------------------------------
1. Launch your running AppShots instance (e.g., http://localhost:5173).
2. Open the Project Switcher in the left sidebar.
3. Choose 'Import Project' and select 'project/project.json' from this archive.
4. All screenshots, custom headlines, device 3D tilts, offsets, and colors
   will load instantly into the interactive canvas.

Exported Screenshots:
  [Slide 1] screen-01-variant-1.png (2048x2732, 998.2 KB) - Route: /

================================================================================